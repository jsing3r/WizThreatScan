import boto3
import json
import logging
import base64
import requests
import time
import datetime
import os
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

"""
Python 3.6+
pip(3) install requests
"""

# SSM Variables
# Wiz 2024 - v2.3
lastScanDateSSM="/threat-scan/lastScanDate"
debugModeSSM="/threat-scan/debugMode"
CLIENT_ID_SSM="/threat-scan/client_id"
CLIENT_SECRET_SSM="/threat-scan/client_secret"
CONNECTOR_LIST_SSM="/threat-scan/connector_list"

# Standard headers
HEADERS_AUTH = {"Content-Type": "application/x-www-form-urlencoded"}
HEADERS = {"Content-Type": "application/json"}

def query_wiz_api(query, variables, dc):
    """Query Wiz API for the given query data schema"""

    data = {"variables": variables, "query": query}

    try:
        # Uncomment the next first line and comment the line after that
        # to run behind proxies
        # result = requests.post(url=f"https://api.{dc}.app.wiz.io/graphql",
        #                        json=data, headers=HEADERS, proxies=proxyDict, timeout=180)
        result = requests.post(url=f"https://api.{dc}.app.wiz.io/graphql",
                               json=data, headers=HEADERS, timeout=180)

    except requests.exceptions.HTTPError as e:
        print(f"<p>Wiz-API-Error (4xx/5xx): {str(e)}</p>")
        return e

    except requests.exceptions.ConnectionError as e:
        print(f"<p>Network problem (DNS failure, refused connection, etc): {str(e)}</p>")
        return e

    except requests.exceptions.Timeout as e:
        print(f"<p>Request timed out: {str(e)}</p>")
        return e

    return result.json()


def request_wiz_api_token(client_id, client_secret):
    """Retrieve an OAuth access token to be used against Wiz API"""

    auth_payload = {
      'grant_type': 'client_credentials',
      'audience': 'wiz-api',
      'client_id': client_id,
      'client_secret': client_secret
    }
    try:
        # Uncomment the next first line and comment the line after that
        # to run behind proxies
        # response = requests.post(url="https://auth.app.wiz.io/oauth/token",
        #                         headers=HEADERS_AUTH, data=auth_payload,
        #                         proxies=proxyDict, timeout=180)
        response = requests.post(url="https://auth.app.wiz.io/oauth/token",
                                headers=HEADERS_AUTH, data=auth_payload, timeout=180)

    except requests.exceptions.HTTPError as e:
        print(f"<p>Error authenticating to Wiz (4xx/5xx): {str(e)}</p>")
        return e

    except requests.exceptions.ConnectionError as e:
        print(f"<p>Network problem (DNS failure, refused connection, etc): {str(e)}</p>")
        return e

    except requests.exceptions.Timeout as e:
        print(f"<p>Request timed out: {str(e)}</p>")
        return e

    try:
        response_json = response.json()
        token = response_json.get('access_token')
        if not token:
            message = f"Could not retrieve token from Wiz: {response_json.get('message')}"
            raise ValueError(message)
    except ValueError as exception:
        message = f"Could not parse API response {exception}. Check Service Account details " \
                    "and variables"
        raise ValueError(message) from exception

    response_json_decoded = json.loads(
        base64.standard_b64decode(pad_base64(token.split(".")[1]))
    )

    response_json_decoded = json.loads(
        base64.standard_b64decode(pad_base64(token.split(".")[1]))
    )
    dc = response_json_decoded["dc"]

    return token, dc


def pad_base64(data):
    """Makes sure base64 data is padded"""
    missing_padding = len(data) % 4
    if missing_padding != 0:
        data += "=" * (4 - missing_padding)
    return data

def readSSM(name, decrypt):
    ssm_client = boto3.client("ssm")

    parameter = ssm_client.get_parameter(Name=name, WithDecryption=decrypt)
    return parameter["Parameter"]["Value"]

def writeSSM(name,value):
    ssm_client = boto3.client("ssm")

    ssm_client.put_parameter(
        Name=name,
        Overwrite=True,
        Value=value,
    )

def readScanDateSSM():
    # Retreive lastScanDate stored in SSM
    return readSSM(lastScanDateSSM, False)
    
def writeScanDateSSM(value):
   # Write lastScanDate out to SSM
   writeSSM(lastScanDateSSM, value)

def getVariables():
    global debugMode, CLIENT_ID, CLIENT_SECRET, CONNECTOR_LIST

    debugMode = readSSM(debugModeSSM, False)
    CLIENT_ID = readSSM(CLIENT_ID_SSM,True)
    CLIENT_SECRET = readSSM(CLIENT_SECRET_SSM,True)
    CONNECTOR_LIST = readSSM(CONNECTOR_LIST_SSM,True)

def checkThreatCenter(dc):

   # Check the Wiz Threat Center
    print("checkThreatCenter initiated")


    # Uncomment the following section to define the proxies in your environment,
    #   if necessary:
    # http_proxy  = "http://"+user+":"+passw+"@x.x.x.x:abcd"
    # https_proxy = "https://"+user+":"+passw+"@y.y.y.y:abcd"
    # proxyDict = {
    #     "http"  : http_proxy,
    #     "https" : https_proxy
    # }

    # The GraphQL query that defines which data you wish to fetch.
    QUERY = """
    query ThreatsCenterItems($first: Int, $after: String, $filterBy: ThreatCenterItemFilters) {
      threatCenterItems(first: $first, after: $after, filterBy: $filterBy) {
        nodes {
          id
          publishedAt
          description
          docsUrl
          iconUrl
          title
          source
          type
          workInProgress
          suggestControlCreation
          licenseFeatureRestricted
          alwaysShowFindingsCount
          tags
          findingLinks {
            type
            label
            filters
          }
        }
        pageInfo {
          endCursor
          hasNextPage
        }
        totalCount
      }
    }
    """

    # The variables sent along with the above query
    VARIABLES = {
    "first": 1
    }

    result = query_wiz_api(QUERY, VARIABLES, dc)
    if debugMode: print(result)  # your data is here!

    return result

def checkScan(result):
    # Check if scan is needed
    if debugMode: print(json.dumps(result, indent=4, sort_keys=True))

    publishedAt = result['data']['threatCenterItems']['nodes'][0]['publishedAt']
    if debugMode: print("publishedAt", publishedAt)

    id  = result['data']['threatCenterItems']['nodes'][0]['id']
    if debugMode: print("id", id)

    type  = result['data']['threatCenterItems']['nodes'][0]['type']
    if debugMode: print("type", type)

    publishedDate = datetime.datetime.strptime(publishedAt, "%Y-%m-%dT%H:%M:%SZ")
    print("publishedDate", publishedDate)

    # read the scan date
    content = readScanDateSSM()
    print("content", content)
    
    if content == "ALWAYS":
        print("ALWAYS selected - force scan")
        return True
        
    try:
       #lastScanDate = datetime.datetime.strptime(content, "%Y-%m-%dT%H:%M:%SZ")
        lastScanDate = datetime.datetime.strptime(content, "%Y-%m-%d %H:%M:%S")
        
    except ValueError as e:
       print("Unable to parse the content: ",e)
       

       # set the lastScanDate
       now = str(datetime.datetime.utcnow().isoformat(timespec="seconds")) + "Z"
       if debugMode: print("current date", now)

       lastScanDate = datetime.datetime.strptime(now, "%Y-%m-%dT%H:%M:%SZ")
       if debugMode: print("Set lastScanDate", lastScanDate)
       
       # write the scan date
       writeScanDateSSM(str(lastScanDate))
      
    if lastScanDate > publishedDate:
       print ("lastScanDate later than publishedDate. No need to scan")
       return False
    elif lastScanDate <= publishedDate:
       print ("lastScanDate earlier than or equal to publishedDate")

       if type == "INFORMATIONAL":
          print("Type is informational, so skip scan")
          return False
       else:
          print("Type is not informational, this is the time to scan")

          # set the lastScanDate
          if debugMode: print("Deprecated lastScanDate", lastScanDate)
          now = str(datetime.datetime.utcnow().isoformat(timespec="seconds")) + "Z"

          lastScanDate = datetime.datetime.strptime(now, "%Y-%m-%dT%H:%M:%SZ")
          print("Reset lastScanDate", lastScanDate)
          
          # update the last scan date
          writeScanDateSSM(str(lastScanDate))
          return True 
    else:
          print("lastScanDate is exactly the same as publishedDate. No way")
          return False

def threatScan(dc):
    # Force the rescan in Wiz
    print("threatScan initiated")


    # Uncomment the following section to define the proxies in your environment,
    #   if necessary:
    # http_proxy  = "http://"+user+":"+passw+"@x.x.x.x:abcd"
    # https_proxy = "https://"+user+":"+passw+"@y.y.y.y:abcd"
    # proxyDict = {
    #     "http"  : http_proxy,
    #     "https" : https_proxy
    # }

    # The GraphQL query that defines which data you wish to fetch.
    QUERY = """
        mutation RequestConnectorScan($input: RequestConnectorScanInput!) {
        requestConnectorScan(input: $input) {
            success
            reason
        }
        }
    """

    connector_list = CONNECTOR_LIST.split(",")
    print("List of connectors", connector_list)
    
    for connector_id in connector_list:
        if debugMode: print("in loop for connector", connector_id)
        
        CONNECTOR = {
        "input": {
            "id": connector_id.strip()
            }
        }
        
        #CONNECTOR = json.dumps(CONNECTOR)
        if debugMode: print("Formatted connector", CONNECTOR)
        
        print("Requesting rescan of connector", CONNECTOR)
        result = query_wiz_api(QUERY, CONNECTOR, dc)
        time.sleep(1)
        
        if debugMode: print(result)  # your data is here!
    else:
        if debugMode: print("out of connector loop")
    
    return True

def lambda_handler(event, context):

    getVariables()
    print("debugMode", debugMode)
    print("Getting token.")
    token, dc = request_wiz_api_token(CLIENT_ID, CLIENT_SECRET)
    HEADERS["Authorization"] = "Bearer " + token

    result = checkThreatCenter(dc)
    if debugMode: print(result)  # your data is here!

    if checkScan(result):
       threatScan(dc)

    logger.info(f"CloudWatch logs group: {context.log_group_name}")
    
    return json.dumps(result)
